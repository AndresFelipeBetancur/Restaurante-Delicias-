#include "../routes/Routes.h"

void registerRoutes(crow::SimpleApp& app) {
    CROW_ROUTE(app, "/")([]() {
        return "Bienvenido a Restaurante Delicias";
    });
}
