#include "crow.h"
#include "routes/Routes.h"

int main() {
    crow::SimpleApp app;
    registerRoutes(app);
    app.port(18080).multithreaded().run();
    return 0;
}
